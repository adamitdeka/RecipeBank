<div class="p-3 bg-dark text-white">
	<!-- Footer Links -->
	<div class="container justify-content-center">

		<!-- Grid row-->
		<div class="row text-center d-flex">

			<!-- Grid column -->
			<div class="col-sm-1">
				<h6>
					<a class="text-white" href="feed.php">Feed</a>
				</h6>
			</div>
			<!-- Grid column -->

			<!-- Grid column -->
			<div class="col-sm-1">
				<h6>
					<a class="text-white" href="index.php">Home</a>
				</h6>
			</div>
			<!-- Grid column -->

			<!-- Grid column -->
			<div class="col-sm-1">
				<h6>
					<a class="text-white" href="sitemap.php">SiteMap</a>
				</h6>
			</div>
			<!-- Grid column -->

	<!-- Grid column -->
	<div class="col-sm-1">
		<h6>
			<a class="text-white" href="faq.php">FAQ</a>
		</h6>
	</div>
			<!-- Copyright -->
			<div class="page-footer footer-copyright text-right col-sm-8">© 2020 Copyright:
				<a class="text-white" href="https://recipebank.com/"> RecipeBank.com</a>
			</div>
			<!-- Copyright -->
			<!-- Grid column -->
		</div>
		<!-- Grid row-->

	</div>
	<!-- Footer Links -->
</div>
