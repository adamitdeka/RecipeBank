<?php
require_once 'traits/valtrait.php';

class subscriberTrait {
    use Validation;
}

